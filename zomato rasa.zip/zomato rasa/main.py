from flask import Flask, redirect, url_for, request, render_template
import requests
import json

app = Flask(__name__, template_folder= 'Templates')
context_set = ""

@app.route('/', methods = ['POST', 'GET'])
def index():

  if request.method == 'GET':
    val = str(request.args.get('text'))
    data = json.dumps({"sender": "Rasa","message": val})
    header = {'Content-type': 'application/json', 'Accept': 'text/plain'}
    res = requests.post('http://localhost:5005/webhooks/rest/webhook', data= data, headers = header)
    res = res.json()
    print(res)
    val = res[0]['text']
    return render_template('index.html', val=val)

if __name__ == '__main__':
  app.run(debug=True)
